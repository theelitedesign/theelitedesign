# basetheme issues

* [ ] there is an issue in team CPT https://i.imgur.com/N0kbZ0k.png
* [ ] how we can remote parmalink from team CPT
* [ ] blog single catagories not dynamic
