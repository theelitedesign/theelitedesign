# Questions

Description for this file goes here

-------------------------------------------------------

## Client Questions

- ask client to send homepage video without text version

## Internal Questions

- animate footer lines
