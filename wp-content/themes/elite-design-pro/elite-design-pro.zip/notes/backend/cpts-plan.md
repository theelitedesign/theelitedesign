# CPTs Plan

Description for this file goes here

-------------------------------------------------------

## Testimonial

* Slug - testimonial
  * www.website.com/testimonial/single-testimonial-name
* Singular - Testimonial
* Plural - Testimonials
* Taxonomy - No present

* [ ] Author Name ( Page title )
* [ ] Author Image ( Image )
* [ ] Text ( WYSIWYG )
* [ ] Featured Image
* [ ] Designation ( Textfield )
