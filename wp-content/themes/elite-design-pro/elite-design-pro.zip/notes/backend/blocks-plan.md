# Blocks Plan

Description for this file goes here

-------------------------------------------------------

### Icon List

* [ ] Icon List (Button Group - Image)
  * [ ] Inclined
  * [ ] W/ Image
* [ ] Image Location (Button Group - Image) (Only for w/image)
  * [ ] Left
  * [ ] Right
* [ ] Title
* [ ] Image (Only for w/image)
* [ ] Lists (Repeater) (Max 3)
  * [ ] Icon
  * [ ] Heading
  * [ ] Text (wysiwyg)
  * [ ] link (link)

### Image Alongside Text

* [ ] Image Location (Button Group - Image)
  * [ ] Left
  * [ ] Right
* [ ] Select Variation (Button Group - Image)
  * [ ] Simple
    * [ ] Heading
    * [ ] Text (wysiwyg)
    * [ ] Button
  * [ ] Graphic
    * [ ]  Logo (image)
    * [ ]  Text (wysiwyg)
    * [ ]  Button
    * [ ]  Image (image)
  * [ ] Bottom Aligned
    * [ ]  Heading
    * [ ]  Text (wysiwyg)
    * [ ]  Image (image)
    * [ ]  Button
  * [ ] Icon
    * [ ]  Heading
    * [ ]  Text (wysiwyg)
    * [ ]  Icon  (image)
    * [ ]  Image (image)

### Stats

* [ ] Stats (Repeater)
  * [ ] Icon (image)
  * [ ] Number (text)
  * [ ] Number Label (text)
  * [ ] Number Text (text)
