# Backend Base Theme Process

Description for this file goes here

-------------------------------------------------------

* Read Comments Carefully again
* create file in notes folder for pending this and project details

## Rules

* logo name shuld be projectname-logo.png
*

## Header

* Open Toolkit.html
  * Check HTML (classes) is same or any difference
    * If any differ then update classes in header.php file.
* Update logo image name
  * Update alt text
  * Add home page url
* Output header nav (WP Menus)

* Header buttons
  * Add Theme options for header options
* Footer Option
  * Add home url link to footer logo
  * **Open Theme Options**
  * add socials share
    * Remove Extra socials share
  * Add columns Headlines
  * Add Columns Menus (WP Menus)
  * Copyright option
  * Add Legal Nav (WP Menu)
* Call to action
  * Theme option
  * Page option
    * Show / Hide option
    * Headline
    * Form (hardcoded)
    * Button






## Need to change into base theme

* change main navigation name to Header Nav
* Footer Menu to Legal Nav
