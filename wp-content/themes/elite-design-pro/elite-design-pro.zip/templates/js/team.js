	jQuery(document).ready(function (jQuery) {
	jQuery(".sm-inner").magnificPopup({
		type: "inline",
		midClick: true,
		mainClass: "mfp-fade",
		class: ".team-popup",
		midClick: true,
	});
	})
